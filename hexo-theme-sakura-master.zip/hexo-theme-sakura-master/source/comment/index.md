---
title: comment
date: 2018-12-20 23:13:48
keywords: 留言板
description: 
comments: true
photos: https://cdn.jsdelivr.net/gh/honjun/cdn@1.4/img/banner/comment.jpg
---
{% raw %}
<div class="entry-content">
  <div class="poem-wrap">
    <div class="poem-border poem-left">
    </div>
    <div class="poem-border poem-right">
    </div>
    <h1>
    念两句诗</h1>
    <p id="poem">
    叙别梦、扬州一觉。</p>
    <p id="info">
    【宋代】吴文英《夜游宫·人去西楼雁杳》</p>
  </div>
</div>
{% endraw %}