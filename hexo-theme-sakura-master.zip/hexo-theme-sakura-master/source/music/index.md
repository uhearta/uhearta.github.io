---
title: music
date: 2018-12-20 23:14:28
keywords: 喜欢的音乐
description: 
comments: false
photos: https://cdn.jsdelivr.net/gh/honjun/cdn@1.4/img/banner/music.jpg
---
{% raw %}
<meting-js
  server="netease"
  type="playlist"
  id="2731690811"
  mutex="true">
</meting-js>

<meting-js
  server="netease"
  type="playlist"
  id="419239189"
  mutex="true">
</meting-js>
{% endraw %}